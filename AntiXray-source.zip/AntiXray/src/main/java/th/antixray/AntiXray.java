package th.antixray;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class AntiXray extends JavaPlugin implements Listener, TabExecutor {

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private static final BlockFace[] FACES = {
            BlockFace.UP, BlockFace.DOWN, BlockFace.NORTH,
            BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST
    };
    private static final int MAX_PLACED = 50_000;

    private final Map<UUID, PlayerData> data = new HashMap<>();
    private final Map<UUID, Set<Long>> placed = new HashMap<>();
    private final Set<UUID> alertsOff = new HashSet<>();
    private final Map<Material, Integer> weights = new EnumMap<>(Material.class);
    private final Set<Material> counted = EnumSet.noneOf(Material.class);

    private long windowMs;
    private int minBlocks;
    private int minScore;
    private double maxRatio;
    private long alertCooldownMs;
    private long vlDecayMs;
    private int punishVl;
    private List<String> punishCommands = new ArrayList<>();
    private int placedCount = 0;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();
        getServer().getPluginManager().registerEvents(this, this);
        var cmd = getCommand("antixray");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
    }

    private void loadSettings() {
        reloadConfig();
        var c = getConfig();
        windowMs = Math.max(10, c.getLong("window-seconds", 600)) * 1000L;
        minBlocks = c.getInt("min-blocks", 40);
        minScore = c.getInt("min-score", 9);
        maxRatio = c.getDouble("max-ratio", 0.05);
        alertCooldownMs = c.getLong("alert-cooldown-seconds", 5) * 1000L;
        vlDecayMs = c.getLong("vl-decay-minutes", 30) * 60_000L;
        punishVl = c.getInt("punish-vl", 0);
        punishCommands = c.getStringList("punish-commands");

        weights.clear();
        ConfigurationSection ores = c.getConfigurationSection("ores");
        if (ores != null) {
            for (String key : ores.getKeys(false)) {
                Material m = Material.matchMaterial(key);
                if (m == null) {
                    getLogger().warning("Unknown ore material: " + key);
                    continue;
                }
                weights.put(m, ores.getInt(key, 1));
            }
        }
        counted.clear();
        for (String key : c.getStringList("counted-blocks")) {
            Material m = Material.matchMaterial(key);
            if (m == null) {
                getLogger().warning("Unknown counted block: " + key);
                continue;
            }
            counted.add(m);
        }
    }

    private static long key(Block b) {
        return b.getBlockKey();
    }

    private boolean exposed(Block b) {
        for (BlockFace f : FACES) {
            Material t = b.getRelative(f).getType();
            if (t.isAir() || t == Material.WATER || t == Material.LAVA) {
                return true;
            }
        }
        return false;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Block b = e.getBlockPlaced();
        if (!weights.containsKey(b.getType())) return;
        if (placedCount >= MAX_PLACED) {
            placed.clear();
            placedCount = 0;
        }
        if (placed.computeIfAbsent(b.getWorld().getUID(), k -> new HashSet<>()).add(key(b))) {
            placedCount++;
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return;
        if (p.hasPermission("antixray.bypass")) return;

        Block b = e.getBlock();
        Material m = b.getType();
        long now = System.currentTimeMillis();

        PlayerData d = data.computeIfAbsent(p.getUniqueId(), k -> new PlayerData());
        d.prune(now - windowMs);

        Integer w = weights.get(m);
        if (w == null) {
            if (counted.contains(m)) d.add(now, 0);
            return;
        }

        Set<Long> set = placed.get(b.getWorld().getUID());
        if (set != null && set.remove(key(b))) {
            placedCount--;
            return; // player-placed ore, ignore
        }
        if (exposed(b)) return; // visible ore, legit

        d.add(now, w);

        if (d.stone < minBlocks || d.score < minScore) return;
        double ratio = (double) d.score / d.stone;
        if (ratio < maxRatio) return;

        flag(p, d, ratio, now);
    }

    private void flag(Player p, PlayerData d, double ratio, long now) {
        if (now - d.lastFlag > vlDecayMs) d.vl = 0;
        d.vl++;
        d.lastFlag = now;

        if (now - d.lastAlert >= alertCooldownMs) {
            d.lastAlert = now;
            Component msg = format("alert", p.getName(), d, ratio);
            getLogger().info(p.getName() + " flagged VL " + d.vl
                    + " score=" + d.score + " blocks=" + d.stone);
            for (Player staff : Bukkit.getOnlinePlayers()) {
                if (staff.hasPermission("antixray.alerts") && !alertsOff.contains(staff.getUniqueId())) {
                    staff.sendMessage(msg);
                }
            }
        }

        if (punishVl > 0 && d.vl >= punishVl) {
            for (String c : punishCommands) {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), c.replace("{player}", p.getName()));
            }
            d.vl = 0;
        }

        d.clearWindow();
    }

    private Component format(String path, String player, PlayerData d, double ratio) {
        String raw = getConfig().getString("messages." + path, "");
        raw = raw.replace("{player}", player)
                .replace("{vl}", String.valueOf(d == null ? 0 : d.vl))
                .replace("{score}", String.valueOf(d == null ? 0 : d.score))
                .replace("{blocks}", String.valueOf(d == null ? 0 : d.stone))
                .replace("{ratio}", String.format(Locale.ROOT, "%.3f", ratio));
        return MM.deserialize(raw);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        data.remove(e.getPlayer().getUniqueId());
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (a.length == 0) {
            s.sendMessage(format("usage", "", null, 0));
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                loadSettings();
                s.sendMessage(format("reloaded", "", null, 0));
            }
            case "alerts" -> {
                if (!(s instanceof Player p)) {
                    s.sendMessage("Players only.");
                    return true;
                }
                if (alertsOff.remove(p.getUniqueId())) {
                    s.sendMessage(format("alerts-on", "", null, 0));
                } else {
                    alertsOff.add(p.getUniqueId());
                    s.sendMessage(format("alerts-off", "", null, 0));
                }
            }
            case "stats" -> {
                if (a.length < 2) {
                    s.sendMessage(format("usage", "", null, 0));
                    return true;
                }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null) {
                    s.sendMessage(format("no-player", "", null, 0));
                    return true;
                }
                PlayerData d = data.get(t.getUniqueId());
                if (d != null) d.prune(System.currentTimeMillis() - windowMs);
                s.sendMessage(format("stats", t.getName(), d, d == null || d.stone == 0 ? 0 : (double) d.score / d.stone));
            }
            default -> s.sendMessage(format("usage", "", null, 0));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            for (String o : List.of("reload", "alerts", "stats")) {
                if (o.startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(o);
            }
        } else if (a.length == 2 && a[0].equalsIgnoreCase("stats")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(a[1].toLowerCase(Locale.ROOT))) {
                    out.add(p.getName());
                }
            }
        }
        return out;
    }

    private static final class PlayerData {
        // each entry: {timestamp, weight}; weight 0 = plain stone
        private final Deque<long[]> events = new ArrayDeque<>();
        int stone = 0;
        int score = 0;
        int vl = 0;
        long lastFlag = 0;
        long lastAlert = 0;

        void add(long time, int weight) {
            events.addLast(new long[]{time, weight});
            if (weight == 0) stone++;
            else score += weight;
        }

        void prune(long cutoff) {
            while (!events.isEmpty() && events.peekFirst()[0] < cutoff) {
                long[] e = events.pollFirst();
                if (e[1] == 0) stone--;
                else score -= (int) e[1];
            }
        }

        void clearWindow() {
            events.clear();
            stone = 0;
            score = 0;
        }
    }
}
